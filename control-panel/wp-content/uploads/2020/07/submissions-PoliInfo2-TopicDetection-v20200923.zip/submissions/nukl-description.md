# Topic Detection $B@bL@%U%!%$%k(B

## $B4pK\J}?K(B
$B5D0w$N<ALd$H$=$N2sEz$+$i%H%T%C%/$r8!=P!%(B
$B%H%T%C%/$r@_$1$F$$$k$N$O<ALd<T$H9M$(!$2sEz$NCf$N%H%T%C%/$i$7$-$b$N$b!$<ALd<T$N<ALd$+$iF3$+$l$?$b$N$H$7$F$k(B

## $B<jK!(B
$BC1=c$J%Q%?!<%s%^%C%A!%(B
$B!V!{!{$K$D$$$F!W$N!V!{!{!W$rCj=P$7$F$$$k!%(B
$BE,9gN($r>e$2$k$?$a$K%Q%?!<%s$r>/$7=$@5$7$F$k$,!$4pK\$O:F8=N(=E;k$N$?$a%4%_$,B?$$!%(B



